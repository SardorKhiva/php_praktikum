# PHP + MySQL

PHPda ikki xil usulda MySQL bazaga ulanib ishlash mumkin:

- MySQLi extension
- PDO (PHP Data Objects)

PDO 12 ta baza turlari bilan ishlay oladi. MySQLi bo'lsa faqat MySQL bilan ishlay oladi.

```php
MySQL
PostgreSQL
Oracle
Firebird
MS SQL Server
Sybase
Informix
IBM
FreeTDS
SQLite
Cubrid
4D

```

[Bazaga ulanish](https://www.notion.so/Bazaga-ulanish-a48da3dbe7d5407aa493da74a0c38ee2?pvs=21)

[Bazaga ma'lumot qo'shish (INSERT)](https://www.notion.so/Bazaga-ma-lumot-qo-shish-INSERT-853e3f6e87e14ed5b284e811140560a2?pvs=21)

[PREPARE](https://www.notion.so/PREPARE-93958596a7d74de4ae54e9e1b9531f25?pvs=21)

[PDOStatement](https://www.notion.so/PDOStatement-849951990fea4fb1819a676ffe1b9cb1?pvs=21)

[Vazifa](https://www.notion.so/Vazifa-b6b54b57b338471fa235042a9958d58f?pvs=21)

[CRUD](https://www.notion.so/CRUD-229ffc5e09da47159b995d7cf142fea6?pvs=21)

[regi login](https://www.notion.so/regi-login-1e0fbb4dc25844ebb74aea3499a99de8?pvs=21)

![Untitled](https://s3-us-west-2.amazonaws.com/secure.notion-static.com/2f7ebf21-3e4d-4777-a2cd-6ec853b53933/Untitled.png)