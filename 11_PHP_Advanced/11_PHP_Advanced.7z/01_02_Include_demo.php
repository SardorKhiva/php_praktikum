<?php

echo "Bu 01_02_Include_demo.php fayli\n";

$color = "yashil";
$meva = 'olma';

function toq (int $a): bool
{
    return $a % 2 === 1;
} 